import threading
import numpy as np
from faster_whisper import WhisperModel
import config


class LiveCaptioner:
    """
    Real-time vocal transcription using faster-whisper.
    Runs entirely offline on the user's PC.
    Activated only when no synced lyrics are found.
    """

    _instance_lock = threading.Lock()   # class-level lock
    _shared_model  = None               # shared across instances
    _model_ready   = False

    def __init__(self, on_new_line):
        self.on_new_line = on_new_line
        self.running     = False
        self.thread      = None

    # ─── Model loading ────────────────────────────────────────────────

    @classmethod
    def _load_model(cls):
        """
        Loads model once — shared across all instances.
        Thread-safe — only one thread loads at a time.
        """
        with cls._instance_lock:
            if cls._model_ready:
                return True
            try:
                print("[Caption] Loading Whisper model...")
                cls._shared_model = WhisperModel(
                    config.WHISPER_MODEL,
                    device       = "cpu",
                    compute_type = "int8"
                )
                cls._model_ready = True
                print("[Caption] Whisper model ready ✅")
                return True
            except Exception as e:
                print(f"[Caption] Failed to load model: {e}")
                return False

    # ─── Start / Stop ─────────────────────────────────────────────────

    def start(self, audio_source=None):
        """Start live captioning."""
        if self.running:
            return

        # load model first — blocks until ready
        if not self._load_model():
            print("[Caption] Cannot start — model not loaded.")
            return

        self.running = True

        self.thread = threading.Thread(
            target=self._caption_loop,
            daemon=True
        )
        self.thread.start()
        print("[Caption] Live captioning started.")

    def stop(self):
        """Stop live captioning."""
        if self.running:
            self.running = False
            print("[Caption] Stopped.")

    # ─── Caption loop ─────────────────────────────────────────────────

    def _caption_loop(self):
        """
        Continuously records audio and transcribes.
        Runs in background thread.
        """
        from src.core.audio import record_audio

        while self.running:
            try:
                audio = record_audio(duration=4)

                # skip silence
                rms = float(np.sqrt(
                    np.mean(audio.astype(float) ** 2)
                ))
                if rms < 50:
                    continue

                line = self._transcribe(audio)

                if line and line.strip():
                    # break into display lines
                    lines = self._break_into_lines(line)
                    for l in lines:
                        if l and self.running:
                            print(f"[Caption] {l}")
                            self.on_new_line(l)

            except Exception as e:
                print(f"[Caption] Loop error: {e}")

    def _transcribe(self, audio: np.ndarray) -> str:
        """Transcribes audio using shared Whisper model."""
        try:
            if not self.__class__._model_ready:
                return ""

            audio_f32 = audio.astype(np.float32) / 32768.0

            segments, _ = self.__class__._shared_model.transcribe(
                audio_f32,
                beam_size                  = 1,
                language                   = None,
                condition_on_previous_text = False,
                vad_filter                 = True,
                vad_parameters             = {
                    "min_silence_duration_ms": 300
                }
            )

            text = " ".join(
                seg.text.strip()
                for seg in segments
                if seg.text.strip()
            )
            return text

        except Exception as e:
            print(f"[Caption] Transcribe error: {e}")
            return ""

    def _break_into_lines(self, text: str) -> list:
        """
        Breaks transcription into display lines.
        Splits on punctuation and caps at MAX_CAPTION_WORDS.
        """
        if not text:
            return []

        import re
        sentences = re.split(r'[,\.!?;]+', text)
        lines     = []

        for sentence in sentences:
            words = sentence.strip().split()
            if not words:
                continue

            while len(words) > config.MAX_CAPTION_WORDS:
                lines.append(
                    " ".join(words[:config.MAX_CAPTION_WORDS])
                )
                words = words[config.MAX_CAPTION_WORDS:]

            if words:
                lines.append(" ".join(words))

        return [l for l in lines if l.strip()]